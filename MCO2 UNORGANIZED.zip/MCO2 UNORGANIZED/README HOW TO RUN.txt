1. cd MCO2 ORGANIZED
2. javac -d . src\*.java
3. java Driver